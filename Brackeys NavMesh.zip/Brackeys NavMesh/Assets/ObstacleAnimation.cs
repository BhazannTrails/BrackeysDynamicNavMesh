﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleAnimation : MonoBehaviour
{

    public Vector3 startPos;
    public float maxX;
    public enum AnimationDirection {Forward, Back};
    AnimationDirection FoB;

    private void Start()
    {
        startPos = transform.position;
        maxX = startPos.x + 10.0f;
        FoB = AnimationDirection.Forward;
    }

    void Update()
    {
        Vector3 pos = transform.position;
        if (pos.x < maxX && FoB == AnimationDirection.Forward)
        {
            pos.x = pos.x + 2f * Time.deltaTime;
            if (pos.x > maxX)
            {
                FoB = AnimationDirection.Back;
            }
        }

        if (FoB == AnimationDirection.Back)
        {
            pos.x = pos.x -= 2f * Time.deltaTime;
            if(pos.x < startPos.x)
            {
                FoB = AnimationDirection.Forward;
            }
        }
            transform.position = pos;
    }
}

