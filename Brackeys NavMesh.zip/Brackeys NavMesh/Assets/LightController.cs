﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightController : MonoBehaviour {

    public Light light;

	// Use this for initialization
	void Start () {

        light = GetComponent<Light>();

	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetKeyUp(KeyCode.Space))
        {
            //Toggle, set this to whatever it isn't.
            light.enabled = !light.enabled;
        }

	}
}
