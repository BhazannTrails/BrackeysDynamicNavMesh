﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour {

    // Use this for initialization
    // Update is called once per frame

    public float panSpeed = 20f;
    public float borderThickness = 2f;

    void Update () {

        Vector3 pos = transform.position;

        if(Input.GetKey("w")||Input.mousePosition.y >= Screen.height)
        {
            pos.z += panSpeed * Time.deltaTime;
        }

        if(Input.GetKey("s")||Input.mousePosition.y <= borderThickness)
        {
            pos.z -= panSpeed * Time.deltaTime;
        }

        if (Input.GetKey("d")||Input.mousePosition.x >= Screen.width)
        {
            pos.x += panSpeed * Time.deltaTime;
        }

        if(Input.GetKey("a")||Input.mousePosition.x <= borderThickness)
        {
            pos.x -= panSpeed * Time.deltaTime;
        }

        transform.position = pos;
	}
}
